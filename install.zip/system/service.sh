#!/sbin/sh

nohup /system/bin/server > /data/local/tmp/server.log 2>&1 &