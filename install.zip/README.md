# mmt-server

## release

```bash
./src/scripts/release.sh
```
