### v1.2 - 16.2.2024
* Add service file

### v1.0 - 16.2.2024
* Initial release