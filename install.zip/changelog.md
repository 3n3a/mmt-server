### v1.0 - 16.2.2024
* Initial release